<?php
// SMTP Configuration for AMOR Event
return [
    'host' => 'mail.hotelsowirad.com',
    'auth' => true,
    'username' => 'marketing@hotelsowirad.com',
    'password' => 'Marketing!2#',
    'secure' => 'ssl', // Port 465 usually requires 'ssl' (Implicit SSL)
    'port' => 465,
    'from_email' => 'marketing@hotelsowirad.com',
    'from_name' => 'AMOR Event',
    'admin_email' => 'marketing@hotelsowirad.com'
];
